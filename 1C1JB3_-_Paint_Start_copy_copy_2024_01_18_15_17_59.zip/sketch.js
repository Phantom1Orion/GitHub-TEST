let penC = 'black';
function setup() {
  createCanvas(400, 400);
  background(220);
  //noStroke();
}

function draw() {
  
  print(mouseX, mouseY);
  
  if (mouseIsPressed) {
    stroke(penC)
    
    strokeWeight(5)
    line(pmouseX,pmouseY, mouseX,mouseY)
  }
}

function keyPressed(){
  
  if (key === "b"){
    penC = 'blue'
  }
  if (key === "y"){
    penC = 'yellow'
  }
   if (key === "r"){
    penC = 'red'
  }
function keyPressed() {
  if(key==='*')
  remove(); //remove whole sketch on mouse press
}
  
  
  
  
  
  
  
}

















