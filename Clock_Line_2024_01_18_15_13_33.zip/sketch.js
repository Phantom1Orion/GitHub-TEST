let angle = 0
let angle2 = 0
let angle3 = 0
let date;
function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES)
  frameRate(10)
  date = new Date()
  print(date.getTime())
 

  
  time = floor(date.getTime()/1000)
  mins = floor(time/60)
 ss= seconds = time % 60;

  
  print(mins);
  mm = mins % 60
  print(ss,mm);
  hoursLeft = floor(mins/60)
  print(hoursLeft)
  hh = hoursLeft % 12 + 8
  print(hh);

  angle = ss * 6
  angle2 = mm * 6
  angle3 = hh * 30
  
  
  
  
  
}

function draw() {
  background('white');
  textSize(20)
  text(time, 150, 100)
  text(hh, 150,150)
  text(mm, 150, 200)
  text(ss, 150,250)
  translate(200,200)
  push()
  rotate(angle)
  
  strokeWeight(8)
  stroke('red')
  line(0,0,0,-170)
  angle = angle + 6
  pop()
  
  
  push()
  rotate(angle2)

  strokeWeight(8)
  line (0,0,0,-160)
  if (angle == 360){
    angle2 = angle2 + 6
    angle = 0
  }
  pop()
  
  push()
 
  rotate(angle3)

  strokeWeight(8)
  
  line (0,0,0,-120)
  if (angle2 == 360){
    angle3 = angle3 + 11.5
    angle2 = 0
    
  }
    
   
  
 pop()


  

  
}

