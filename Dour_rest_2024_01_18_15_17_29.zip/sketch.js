let penC = "black";
let penW = 8;
let mode = 'line'
function setup() {
  createCanvas(500, 500);
  background(220);
  //noStroke();
  fill('green')
  ellipse(430,400,100,100)
  fill('black')
  textSize(15)
  text('Text size',400,400)
  fill('red')
  textSize(20)
  text('eraser', 370, 0)
   
    
}

function draw() {
  strokeWeight(1);
  stroke("black");
  fill("yellow");
  rect(0, 0, 50, 50);
  fill("red");
  rect(50, 0, 50, 50);
  fill("blue");
  rect(100, 0, 50, 50);
  fill("green");
  rect(150, 0, 50, 50);
  fill("white");
  rect(200, 0, 50, 50);
  fill("black");
  rect(250, 0, 50, 50);
    fill('black')
  rect(350,0,100,50)
  fill('red')
  textSize(20)
  text('eraser', 370, 35)
  noStroke()
   
 
  
  //detect yellow
  if (
    mouseIsPressed &&
    mouseX > 0 &&
    mouseX < 50 &&
    mouseY > 0 &&
    mouseY < 50
  ) {
    penC = "yellow";
  }
  //detect red
  if (
    mouseIsPressed &&
    mouseX > 50 &&
    mouseX < 100 &&
    mouseY > 0 &&
    mouseY < 50
  ) {
    penC = "red";
  }

  //detect blue
  if (
    mouseIsPressed &&
    mouseX > 100 &&
    mouseX < 150 &&
    mouseY > 0 &&
    mouseY < 50
  ) {
    penC = "blue";
  }

  //detect green
  if (
    mouseIsPressed &&
    mouseX > 150 &&
    mouseX < 200 &&
    mouseY > 0 &&
    mouseY < 50
  ) {
    penC = "green";
  }

  //detect white
  if (
    mouseIsPressed &&
    mouseX > 200 &&
    mouseX < 250 &&
    mouseY > 0 &&
    mouseY < 50
  ) {
    penC = "white";
  }

  //detect black
  if (
    mouseIsPressed &&
    mouseX > 250 &&
    mouseX < 300 &&
    mouseY > 0 &&
    mouseY < 50
  ) {
    penC = "black";
  }
  //detect ERASE
  if (
    mouseIsPressed &&
    mouseX > 350 &&
    mouseX < 450 &&
    mouseY > 0 &&
    mouseY < 50
  ) {
    mode = 'eraser'
    ellipse(mouseX, mouseY, 20,20);
    fill(220)
    
    
    
    
}

 if (
    mouseIsPressed &&
    mouseX > 440 &&
    mouseX < 500 &&
    mouseY > 400 &&
    mouseY < 500
  ) {
    penW = prompt("Text Size")
  }  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
   

  if (mouseIsPressed && mode == "line") {
    stroke(penC);

    strokeWeight(8);
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
  
  else if (mouseIsPressed && mode == 'eraser'){
    fill(220)
    ellipse(mouseX,mouseY,20,20)
  }
if (mode == 'eraser' && mouseIsPressed &&
    mouseX > 250 &&
    mouseX < 300 &&
    mouseY > 0 &&
    mouseY < 50){
  mode = 'line'
  penC = 'black'
  
}
  //detect random color
  if (key === "#") {
    penC = color(mouseX, mouseY, 220);
  
  }
   //detect random color
  if (key === "$") {
    penC = color(mouseX, mouseY, 40);
  
  }
  
  
  
  
  
  
  
  
  
}

function keyPressed() {
  if (key === "1") {
    penW = 8;
  }
  if (key === "2") {
    penW = 10;
  }
  if (key === "3") {
    penW = 15;
  }
  if (key === "4") {
    penW = 20;
  }
  if (key === "5") {
    penW = 4;
  }
  if (key === "b") {
    penC = "blue";
  }
  if (key === "y") {
    penC = "yellow";
  }
  if (key === "r") {
    penC = "red";
  }
  if (key === "g") {
    penC = "green";
  }
  if (key === "w") {
    penC = "white";
  }
  
//detect clear
  if (key === "0") {
    background(220);
    fill('green')
  ellipse(430,400,100,100)
  fill('black')
  textSize(15)
  text('Text size',400,400)
  }
 //detect circle lines
  if (key === "e") {
    ellipse(mouseX, mouseY, 20, 20);
fill('penC')
  } 
 
  
  
  
  
  }
  
  
  

