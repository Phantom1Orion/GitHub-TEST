function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(mouseX, mouseY, 55);
  fill('green')
  rect(130,180,30,320)
  flower(140, 140, 30, "yellow", "red");
  fill('green')
  
  flower(50, 300, 20, "blue", "yellow");
  flower(300,300, 20, "green", "purple");
  flower(400, 80, 35, "turquoise", "darkblue");
}

function flower(x, y, radius, pColor, bColor) {
  //1st petal
  fill(pColor);
  circle(x - radius, y - radius, radius * 2);

  //2nd petal
  fill(pColor);
  circle(x + radius, y + radius, radius * 2);

  //3rd petal
  fill(pColor);
  circle(x + radius, y - radius, radius * 2);

  //4th petal
  fill(pColor);
  circle(x - radius, y + radius, radius * 2);

  //flower bud
  fill(bColor);
  circle(x, y, radius * 2);
}
