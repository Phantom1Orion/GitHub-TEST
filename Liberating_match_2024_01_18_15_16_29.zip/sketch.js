
let gap = 20


function setup() {
  createCanvas(400, 400);
  
 iconW = height/6;
 iconX= 5*height/6.5
  noFill();
  
line(20, 40, 80, 40);
}

function draw() {
  background(242, 218, 111);
  stroke('black')
  
  line(0,200,400,200)
  
  //circle
  strokeWeight(5.5); // thicker
  noFill()
  circle(width/2 - iconW - gap,height/4,iconW)

  
  //square
  noFill()
  square(width/2 - iconW/ 2 + iconW + gap,height/4 - iconW / 2,iconW)
  
  //triangle
  noFill()
  triangle(width/2 -iconW/2, height/4 - iconW/2 + iconW, width/2 - iconW/2 + iconW, height/4 - iconW/2 +iconW, width/2 -iconW/2 + iconW/2, height/4 -iconW/2)

  
  
  
 fill(242, 218, 111) 
  circle(width/4, iconX - iconX/19, iconW + iconW/2)
   fill('black')
  circle(width/4, iconX - iconX/19, iconW+iconW/3.5)
  

  stroke('tan')
  strokeWeight(2)
  line(width/4, iconX-iconX/5, width/7.49, iconX-iconX/18)
  line(width/7.50, iconX-iconX/18, width/2.79, iconX-iconX/18)
  line(width/2.79, iconX-iconX/18,width/4, iconX-iconX/5)
  
  let A = ( -sqrt((iconW+iconW/3.5)/2)) //bottom left of trapezium
  let B = ( +sqrt((iconW+iconW/3.5)/2)) //bottom right of trapezium
  let C = ( + sqrt((iconW+iconW/3.5)/2)) //y of trapezium
  
  line(A,C,B,C)
  
  
  text('8606 0079', width/2.3, iconX)
  textSize(30)
  textFont('Courier New')
  textStyle(BOLD)
  
  
  
  
  
  
  
  
  
  
}
