function setup() {
  createCanvas(400, 400);
  angleMode(DEGREES)
}


function emoji() {
  noStroke()
  fill('tan')
  ellipse(height/2, width/2, height/1.5);
  fill('black')
  ellipse(height/2, width/1.9, height/10);
  ellipse(height/1.5,width/1.9, height/10);
  fill(240, 119, 79)
  arc(height/2, width/1.6, width/2.5, height/2.5, 0, 180);
  
  
}
function draw() {
  background('cyan');
 
  emoji()
  rotate(45)
 loop(emoji(random(0-400, 0-400)))
 
  
}