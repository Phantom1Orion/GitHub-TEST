


function setup() {
  createCanvas(400, 400);
  
  background('blue')
  
  fill('green')
  push()
  translate(200,200)
  Fish(80)
  pop()
  
}

function Bubble() {
  let bSize = random(10,40)
  noStroke()
  fill('white')
  circle(0,0,bSize)
  
}

function Fish(fLen) {

  let fW = fLen
  let fH = fLen * 0.8
  fill('green')
  ellipse( 0, 0, fW, fH)  
  triangle( fW/2, 0, fW/2 +fW * 0.3, -fH/2, fW/2 +fW * 0.3, fH/2)
  fill('black')
  ellipse(-15, 0, fW/6, fH/5)
  fill('white')
  ellipse(-17,0, fW/8, fH/10)
  
  
  
}

function mousePressed () {
 if (mousePressed = LEFT) { 
  push()
  translate(mouseX, mouseY)
  Fish(random(20,140))
  
 } else { (mousePressed = RIGHT)
    push()
  Bubble()
  pop()
         
}
 
}
  
function draw() {

}