
//let drawFish = position of fish

let v1;
function setup() {
  createCanvas(400, 400);
  translate (200,200);
  
  v1 = createVector(width / 2, height / 2);
  v2 = createVector(width/2, height/10)
}


function drawFish(fLen) {
  
  fill('pink')
  noStroke()
  ellipse(v1.x, v1.y, mouseX, mouseY);
  describe(`draws a circle from center of canvas to mouse pointer position.`);
  fill('green')
  triangle(v1.x,v2.y, v2.x, v1.y, mouseX, mouseY)
  
}


function draw() {
  background(37, 87, 250);
 drawFish()
 
}



