let i = 0;
function setup() {
  createCanvas(400, 400);
  frameRate(1)
}

function sevenseg(digitW, num){
  let cellw = digitW / 5;
  let cornerRad = cellw / 4
  
  
  if (num == 1 || num == 4){
    noFill();
  }
  else{
    fill('red')
  }
  //segment a (1,0,3,1)
  rect (1* cellw, 0* cellw, 3* cellw,1* cellw, cornerRad)
  
  if (num == 5 || num == 6){
    noFill();
  }
  else{
    fill('red')
  }
  
  //segment b (4,1,1,3)
  
  rect(4*cellw,1*cellw,1*cellw,3*cellw, cornerRad)
  
  if (num == 2){
    noFill();
  }
  else{
    fill('red')
  }
  
  //segment c (4,5,1,3)
  rect(4*cellw,5*cellw,1*cellw,3*cellw, cornerRad)
  
  if (num == 1 || num == 4 || num == 7){
    noFill();
  }
  else{
    fill('red')
  }
  
  //segment d (1,8,3,1)
  rect(1*cellw,8*cellw,3*cellw,1*cellw, cornerRad)
  
  if (num == 1 || num == 3 || num == 4 || num == 5 || num == 7 || num == 9){
    noFill();
  }
  else{
    fill('red')
  }
  
  //segment e (0,5,1,3)
  rect(0*cellw,5*cellw,1*cellw,3*cellw, cornerRad)
  
  if(num == 1 || num == 2 || num == 3 || num ==7){
    noFill();
  }
  else{
    fill('red')
  }
  
  //segment f (0,1,1,3)
  rect(0*cellw,1*cellw,1*cellw,3*cellw, cornerRad)
  
  if (num == 0 || num == 1 || num == 7){
    noFill();
  }
  else{
    fill('red')
  }
  
  //segment g (1,4,3,1)
  rect(1*cellw,4*cellw,3*cellw,1*cellw, cornerRad)
  
}

function draw() {
  background(220);
  sevenseg(100, i);
  i = i + 1;
  if (i == 10){
    i = 0
  }
  
}