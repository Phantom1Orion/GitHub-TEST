function setup() {
  createCanvas(400, 400);
}

function birdie(x, y, color= 'black'){
  fill(color)
  stroke('black')
  rect(x, y, 60, 30)
  rect(x, y, 30, 60)
}

function draw() {
  background(15, 199, 219);
fill('yellow')
  circle(width/8, height/8, 80)
  fill(187, 222, 62)
rect(width/500, height/1.25, width, height)
  fill(22, 71, 33)
  triangle(200, 320, 300, 175, 400, 320)
  fill(22, 71, 33)
  triangle(2, 320, 130, 205, 400, 320)
  line(200, 0, 200, 400)
  line(0, 200, 400, 200)
  //bird
  birdie(width/3, height/3)
  birdie(width/3, height/3)
  
  





}