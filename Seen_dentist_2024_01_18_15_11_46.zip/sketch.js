function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  for(let x =0;x<=400;x=x+0.2){
  let c = lerpColor (color('orange'),color('blue'), x/400)

  
  
  stroke(c)
  line(x,0,x,400)
  }
  
}