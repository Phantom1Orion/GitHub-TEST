let x;
let y;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("turquoise");
  x = mouseX;
  y = mouseY;
  if (x < 200) {
    if (y < 200) {
      fill("blue");
      rect(0, 0, width / 2, height / 2);
    }
  }
  if (x > 200) {
    if (y < 200) {
      fill("yellow");
      rect(200, 0, width / 2, height / 2);
    }
  }
  if (x < 200) {
    if (y > 200) {
      fill("red");
      rect(0, 200, width / 2, height / 2);
    }
  }
  if (x > 200) {
    if (y > 200) {
      fill("green");
      rect(200, 200, width / 2, height / 2);
    }
  }
}
