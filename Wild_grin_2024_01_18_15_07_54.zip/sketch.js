function setup() {
  // bg = loadImage();
  createCanvas(600, 600);
  
  background(50, 168, 127);
  

  noFill();
  for (let x = 50; x <= width; x += 50) {
    for (let y = 50; y <= height; y += 50) {
      if (x === y) {
        gradCircle(x, y, 70, "yellow", "red");
      } else {
        gradCircle(x, y, 25, "blue", "white");
      }
    }
  }
}

function gradCircle(x, y, size, sC, eC) {
  for (let i = 2; i <= size; i++) {
    c = lerpColor(color(sC), color("black"), i / size);
    stroke(c);
    circle(x, y, i);
    stroke("black");
    strokeWeight(3);
    square(x, y, i);
    fill(mouseX, mouseY, 225);
    circle(pmouseX, pmouseY, 10);
  }
}
function draw() {
  
}
